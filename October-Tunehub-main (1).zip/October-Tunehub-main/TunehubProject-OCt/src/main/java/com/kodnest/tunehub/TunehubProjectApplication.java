package com.kodnest.tunehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TunehubProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TunehubProjectApplication.class, args);
	}

}
